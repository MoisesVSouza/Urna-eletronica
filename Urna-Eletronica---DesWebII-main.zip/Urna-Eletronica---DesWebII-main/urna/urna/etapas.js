let etapas = [
    {
        titulo: 'PRESIDENTE',
        numeros: 2,
        candidatos: [
            {
                numero: '01',
                nome: 'Bob Esponja',
                partido: 'ABC',
                fotos: [
                    {url: 'bob_esponja.png', legenda: 'Presidente'}
                ]
            },
            {
                numero: '02',
                nome: 'Lula Molusco',
                partido: 'DEFG',
                fotos: [
                    {url: 'lula_molusco.png', legenda: 'Presidente'}
                ]
            }       
        ]       
    }
]